let nama = prompt('Hallow Sob!! Silakan Masukkan Nama Kamu')

let benar = prompt (" Masukkan 1 jika Benar, masukkan selain 2 jika Salah")

let cek = confirm("Apakah Kamu Yakin?")

let hasil = benar == "1" ? "Benar"  : "Salah"

alert(hasil)